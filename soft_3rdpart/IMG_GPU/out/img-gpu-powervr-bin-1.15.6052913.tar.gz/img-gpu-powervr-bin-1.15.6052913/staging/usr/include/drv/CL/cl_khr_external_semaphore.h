#include "cl_khr_semaphore.h"

#ifndef __OPENCL_CL_KHR_EXTERNAL_SEMAPHORE_H
#define __OPENCL_CL_KHR_EXTERNAL_SEMAPHORE_H

#define CL_SEMAPHORE_DESC_KHR									0x2460
#define CL_PLATFORM_SEMAPHORE_HANDLE_TYPES_KHR					0x2461
#define CL_PLATFORM_SEMAPHORE_EXPORTABLE_HANDLE_TYPES_KHR		0x2462

#define CL_INVALID_EXT_SEMAPHORE_DESC 1

typedef enum _cl_semaphore_handle_type__enum {
    CL_SEMAPHORE_HANDLE_TYPE_OPAQUE_FD= 1,
    CL_SEMAPHORE_HANDLE_TYPE_OPAQUE_WIN32 = 2,
    CL_SEMAPHORE_HANDLE_TYPE_OPAQUE_WIN32_KMT = 3,
    CL_SEMAPHORE_HANDLE_TYPE_SYNC_FD = 4,
} cl_semaphore_handle_type;

typedef struct _cl_semaphore_desc_st {
    cl_semaphore_handle_type type;
    void *handle;
	cl_bool isExportable;
	cl_semaphore_handle_type exportType;
} cl_semaphore_desc;
                                                 
#endif /*__OPENCL_CL_KHR_EXTERNAL_SEMAPHORE_H*/
