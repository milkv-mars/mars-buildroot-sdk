
#ifndef __OPENCL_CL_SEMAPHORE_H
#define __OPENCL_CL_SEMAPHORE_H

#include <CL/cl.h>

#ifdef __cplusplus
extern "C" {
#endif

#define CL_COMMAND_SEMAPHORE_WAIT_KHR                   0x2050
#define CL_COMMAND_SEMAPHORE_SIGNAL_KHR                 0x2051

#define CL_SEMAPHORE_CONTEXT_KHR						0x2452
#define CL_SEMAPHORE_REFERENCE_COUNT_KHR				0x2453
#define CL_SEMAPHORE_PROPERTIES_KHR						0x2454
#define CL_SEMAPHORE_TYPE_KHR							0x2455

#define CL_PLATFORM_SEMAPHORE_TYPES_KHR					0x2456

typedef enum _cl_semaphore_type__enum {
    CL_SEMAPHORE_TYPE_BINARY= 1,
} cl_semaphore_type;

typedef cl_properties cl_semaphore_properties_khr;
typedef cl_uint cl_semaphore_info;

typedef struct _cl_semaphore* cl_semaphore;
typedef cl_ulong cl_semaphore_payload;

typedef CL_API_ENTRY cl_semaphore
(CL_API_CALL *clCreateSemaphoreKHR_fn)(cl_context 					psContext, 
									   cl_semaphore_properties_khr* sema_props, 
									   cl_int* 						pui32ErrorCodeRet);

extern CL_API_ENTRY cl_semaphore CL_API_CALL
clCreateSemaphoreKHR(cl_context psContext,
					 cl_semaphore_properties_khr* sema_props,
					 cl_int* pui32ErrorCodeRet)  CL_API_SUFFIX__VERSION_1_2;

typedef CL_API_ENTRY cl_int
(CL_API_CALL *clEnqueueSignalSemaphoresKHR_fn)(cl_command_queue				psCommandQueue,
								 				cl_uint						uiNumSemaphoresInList,
								 				const cl_semaphore*			ppsSemaphoreList,
								 				const cl_semaphore_payload*	ppsSemaphorePayloadList,
								 				cl_uint						uiNumEventsInWaitList,
								 				const cl_event*				ppsEventWaitList,
								 				cl_event*					ppsEvent);

extern CL_API_ENTRY cl_int CL_API_CALL
clEnqueueSignalSemaphoresKHR (cl_command_queue command_queue,
                              cl_uint num_sema_descs,
                              const cl_semaphore *sema_list,
                              const cl_semaphore_payload *sema_payload_list,
                              cl_uint num_events_in_wait_list,
                              const cl_event *event_wait_list,
                              cl_event *event)  CL_API_SUFFIX__VERSION_1_2;

typedef CL_API_ENTRY cl_int
(CL_API_CALL *clEnqueueWaitForSemaphoresKHR_fn)(cl_command_queue			   	psCommandQueue,
								  				cl_uint					   		uiNumSemaphoresInList,
								  				const cl_semaphore*		   		ppsSemaphoreList,
								  				const cl_semaphore_payload*  	ppsSemaphorePayloadList,
								  				cl_uint					   		uiNumEventsInWaitList,
								  				const cl_event*			   		ppsEventWaitList,
								  				cl_event*					   	ppsEvent);


extern CL_API_ENTRY cl_int CL_API_CALL
clEnqueueWaitForSemaphoresKHR (cl_command_queue command_queue,
                               cl_uint num_sema_descs,
                               const cl_semaphore *sema_list,
                               const cl_semaphore_payload *sema_payload_list,
                               cl_uint num_events_in_wait_list,
                               const cl_event *event_wait_list,
                               cl_event *event)  CL_API_SUFFIX__VERSION_1_2;

extern CL_API_ENTRY cl_int CL_API_CALL
clGetSemaphoreInfoKHR(const cl_semaphore semaphore,
					  cl_semaphore_info param_name,
					  size_t param_value_size,
					  void *param_value,
					  size_t *param_value_size_ret)  CL_API_SUFFIX__VERSION_1_2;

typedef CL_API_ENTRY cl_int 
(CL_API_CALL *clGetSemaphoreInfoKHR_fn)(cl_semaphore 	psSemaphore, 
							 cl_semaphore_info 			param_name, 
							 size_t 					param_size, 
							 void* 						param_value, 
							 size_t* 					param_size_ret);


typedef CL_API_ENTRY cl_int 
(CL_API_CALL *clReleaseSemaphoreKHR_fn)(cl_semaphore 	psSemaphore);

extern CL_API_ENTRY cl_int CL_API_CALL
clReleaseSemaphoreKHR (cl_semaphore sema_object) CL_API_SUFFIX__VERSION_1_2;

#ifdef __cplusplus
}
#endif

#endif /*__OPENCL_CL_SEMAPHORE_H*/


